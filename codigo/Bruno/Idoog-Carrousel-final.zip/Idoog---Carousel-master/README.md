# LopeszD.github.io
Carousel idoog para trabalho interdisciplinar de aplicações web da faculdade PUC MINAS, Grupo: PETS 2
web: LopeszD.github.io
